Aim Trainer Hindi - free starter package

Files:
- aim_trainer.html : game
- manifest.json : PWA app metadata
- service-worker.js : offline cache starter

To test: open aim_trainer.html in a modern Android browser. Sound/vibration support varies by browser/device; vibration may not work on all phones. High score is saved in the same browser's local storage.

For PWA/offline installation, host the files on an HTTPS website and register service-worker.js from a page. For an Android APK, use a trusted PWA-to-Android packaging service/build workflow; it generally needs a public HTTPS URL and may require signing/package setup. Never enter passwords or pay unexpectedly.
